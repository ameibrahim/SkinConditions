-- users
    -- id
    -- name
    -- email
    -- password
    -- role

    -- [{
    --     id: 'h034hds',
    --     name: 'Ibrahim Ame',
    --     email: 'ame.ibrahim@yahoo.com',
    --     password: 'hello123',
    --     role: 'admin'
    -- }]

-- collaborators
    -- id
    -- name
    -- imagePath

    -- [{
    --     id: '90g2h45',
    --     name: 'Ibrahim Ame',
    --     image_path: '924589298925.jpg'
    -- }]

-- predictions
    -- id
    -- userID
    -- date
    -- modelID
    -- result
    -- filesize

-- model settings

    -- id
    -- userID
    -- modelID

-- models
    -- id
    -- name
    -- filename
    -- type
    -- metrics
    -- dateTrained
    -- filesize