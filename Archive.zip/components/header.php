<div class="header">
    <div class="left-side">

    </div>
    
    <div class="right-side">
        <img src="assets/logos/rcaiot-logo.png" alt="">
        <img src="assets/logos/desam.svg" alt="">
    </div>
</div>