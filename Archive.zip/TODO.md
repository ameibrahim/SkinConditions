1. Create a popup for the models, so we can see more metadata
2. Media queries for mobile view
4. Knowledgebase page
5. Model select for prediction with saved settings
3. Pagination for past predictions
